# KOODI ARHITEKTUUR JA SELGITUS - v1.7.5

**Kuupäev:** 13.11.2025
**Versioon:** v1.7.5
**Eesmärk:** Selgitada kuidas kood töötab, mis terminoloogia on, kuidas süsteemid omavahel suhtlevad

---

## ÜLEVAADE

Medical Portal on **holistilik medisiiniportaal**, mis koosneb:
1. **18 sektsioonist** (full-profile.html)
2. **6692 rida JavaScripti** (10 faili)
3. **MED_INFO_DB** (112 info kirjet)
4. **Profiilifiltri süsteem** (rasedus, vanus, sugu, riskid)
5. **Plus-nupud süsteem** (50+ kiirvalikut)
6. **Belief-scope süsteem** (spirituaalsed väljad)

---

## PÕHILISED FAILID JA NENDE ROLL

### 1. `medportal/forms/full-profile.html` (Täisprofiili vorm)

**Roll:** Peamine HTML vorm, kus kasutaja sisestab andmed.

**Struktuur:**
- 18 sektsiooni (`<section>` tag'idega)
- Iga sektsioon on jagatud alamosadeks (`<div class="field-group">`)
- Plus-nupud (`<button onclick="quickAddX(...)">`)
- Info-nupud (`<span class="info-icon" onclick="showMedInfo(...)">i</span>`)

**Näide:**
```html
<section id="section-kaebused">
    <h2>3. Kaebused ja sümptomid</h2>

    <div class="field-group">
        <label>Levinumad kaebused:</label>
        <div class="plus-buttons">
            <button type="button" class="plus-btn" onclick="quickAddComplaint('peavalu', 'Peavalu')">
                + Peavalu
                <span class="info-icon" onclick="showMedInfo('peavalu'); event.stopPropagation();">i</span>
            </button>
            <button type="button" class="plus-btn" onclick="quickAddComplaint('liigesevalu', 'Liigesevalu')">
                + Liigesevalu
                <span class="info-icon" onclick="showMedInfo('liigesevalu'); event.stopPropagation();">i</span>
            </button>
        </div>
        <div id="quickAddedComplaints"></div>
    </div>
</section>
```

**Olulised ID'd:**
- `quickAddedComplaints` - siia lisatakse dünaamiliselt valitud kaebused
- `profileSummary` - sticky header profiilifiltri kokkuvõttega
- `profileWarnings` - hoiatused (rasedus, AF+antikoagulant, jne)

---

### 2. `medportal/js/info-system.js` (MED_INFO_DB + quickAdd funktsioonid)

**Roll:** Peamine andmebaas ja plus-nuppude loogika.

**MED_INFO_DB struktuur:**
```javascript
const MED_INFO_DB = {
    'viirpuu': {
        title: 'Viirpuu (Crataegus)',
        shortInfo: 'Südamele toetav taim, parandab vereringet...',
        ourInfo: `<h4>Viirpuu</h4><p><strong>Toime:</strong> ...</p>`,
        externalInfo: `<p><strong>Lisalugemist:</strong><ul><li>...</li></ul></p>`
    },
    'peavalu': {
        title: 'Peavalu',
        shortInfo: 'Valu peas, võib olla pingepeavalude, migreeni või muu põhjusega.',
        ourInfo: `<h4>Peavalu</h4><p>...</p>`,
        externalInfo: `<p>...</p>`
    },
    // ... kokku 112 kirjet
};
```

**quickAdd funktsioonide üldine struktuur:**

```javascript
function quickAddX(key, name) {
    // 1. LOENDUR (mitu korda on lisatud)
    if (!quickAddCounters.x) quickAddCounters.x = 0;
    quickAddCounters.x++;

    // 2. CONTAINER (kus dünaamilised väljad on)
    const containerId = 'quickAddedX';
    let container = document.getElementById(containerId);

    if (!container) {
        // Loo container kui ei eksisteeri
        container = document.createElement('div');
        container.id = containerId;
        container.className = 'added-items-container';
        // Lisa õigesse kohta HTML-is
    }

    // 3. ITEM DIV (üks lisatud kirje)
    const itemId = `x_quick_${quickAddCounters.x}`;
    const fieldName = `x_${key}_${quickAddCounters.x}`;

    const itemDiv = document.createElement('div');
    itemDiv.id = itemId;
    itemDiv.className = 'added-item';
    itemDiv.style.backgroundColor = '#fef2f2';  // Värv vastavalt kategooriale

    // 4. CHECKBOX (kas on aktiivne)
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.name = fieldName;
    checkbox.value = name;
    checkbox.checked = true;
    checkbox.id = fieldName;

    // 5. LABEL (nimi)
    const label = document.createElement('label');
    label.htmlFor = fieldName;
    label.textContent = name;
    label.style.marginLeft = '5px';

    // 6. INFO ICON (kui MED_INFO_DB's on kirje)
    if (MED_INFO_DB[key]) {
        const infoSpan = document.createElement('span');
        infoSpan.className = 'info-icon';
        infoSpan.textContent = 'i';
        infoSpan.onclick = () => showMedInfo(key);
        // ...
    }

    // 7. REMOVE BUTTON (kustutamiseks)
    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'remove-btn';
    removeBtn.textContent = 'x';
    removeBtn.onclick = () => {
        document.getElementById(itemId).remove();
    };

    // 8. INLINE NOTES (täpsustused)
    const notesDiv = document.createElement('div');
    notesDiv.style.marginTop = '5px';
    notesDiv.innerHTML = `
        <label style="font-size: 0.9em;">Täpsustus:</label>
        <input type="text" name="${fieldName}_notes" placeholder="Sagedus, kestus, märkused...">
    `;

    // 9. LISA KÕIK KOKKU
    itemDiv.appendChild(checkbox);
    itemDiv.appendChild(label);
    itemDiv.appendChild(infoSpan);  // kui on
    itemDiv.appendChild(removeBtn);
    itemDiv.appendChild(notesDiv);

    // 10. LISA CONTAINER'ISSE
    container.appendChild(itemDiv);

    // 11. TOAST (kasutaja tagasiside)
    showToast(`${name} lisatud!`);
}
```

**Olemasolevad quickAdd funktsioonid:**
- `quickAddResidence()` - elupaik
- `quickAddMobility()` - liikumine
- `quickAddComplaint()` - kaebused
- `quickAddBath()` - vann/saun
- `quickAddMusic()` - muusika
- `quickAddSleep()` - uni
- `quickAddPrivacy()` - privaatsus (kolmeastmeline routing!)
- `quickAddLifestyle()` - eluviis/transport
- `quickAddActivity()` - füüsiline aktiivsus
- `quickAddTeaType()` - tee liigid
- `quickAddRestriction()` - toitumise piirangud
- `quickAddAccess()` - ligipääs terviseallikatele
- `quickAddFamilyRisk()` - perekondlik risk

---

### 3. `medportal/js/profile-filter.js` (Profiilifiltri loogika)

**Roll:** Jälgib kasutaja profiili (rasedus, vanus, sugu, riskid) ja näitab hoiatusi.

**profileFilter objekt (globaalne muutuja):**
```javascript
const profileFilter = {
    pregnancy: null,              // 'pregnant' | 'breastfeeding' | 'planning' | 'no'
    pregnancyWeeks: null,         // kui pregnant
    planningHorizon: null,        // '<3months' | '3-6months' | '6-12months' | '>12months'
    ageCategory: null,            // '18-39' | '65-74' | '100-120', etc
    ageCategoryLabel: null,       // 'Noor täiskasvanu (18-39 a)'
    exactAge: null,
    gender: null,                 // 'male' | 'female' | 'other'
    afAnticoagulant: false,       // Kodade virvendus + antikoagulant
    egfr: null,                   // neerutalitus
    childPugh: null               // maksa talitus
};
```

**Peamised funktsioonid:**

1. **`selectAgeCategory(button, ageRange, label)`**
   - Kasutaja klikib vanusekategooria plus-nupul
   - Eemaldab "selected" teistelt nuppudelt
   - Lisa "selected" valitud nupule
   - Salvesta hidden field'idesse
   - Kutsu välja `updateProfileFilter()`

2. **`updateProfileFilter()`**
   - Loe väärtused vormist (rasedus, vanus, sugu, riskid)
   - Uuenda `profileFilter` objekti
   - Näita/peida raseduse nädalate väli
   - Kui rasedus või imetamine, aktiveeri automaatselt "naine"
   - Kutsu välja `updateProfileSummary()` ja `updateProfileWarnings()`

3. **`updateProfileSummary()`**
   - Genereeri lühike kokkuvõte (nt "Rasedus 12 nädalat | Noor täiskasvanu (18-39 a) | Naine")
   - Näita sticky header'is

4. **`updateProfileWarnings()`**
   - Kontrolli profiili
   - Kui rasedus → näita hoiatust "Väldi: ginkgo, ginseng, naistepuna, lagrits, kelp"
   - Kui AF+antikoagulant → näita hoiatust "Verejooksu risk"
   - Kui eGFR madal → näita hoiatust "Neerukoormuse piirangud"
   - Kui Child-Pugh → näita hoiatust "Maksakoormus"

**Hoiatuste värvikooder:**
```javascript
// Rasedus/imetamine: punane (#fee)
// AF+antikoagulant: punane (#fee)
// eGFR madal: oranž (#ffeaa7)
// Child-Pugh: oranž (#ffeaa7)
// Eakad: kollane (#fff9db)
// Lapsed: kollane (#fff9db)
```

---

### 4. `medportal/js/full-profile.js` (UI loogika)

**Roll:** Dünaamilised funktsioonid vormil (BMI kalkulaator, drag-and-drop, jne).

**Funktsioonid:**

1. **`calculateBMI()`**
   - Loe pikkus (cm) ja kaal (kg)
   - Arvuta BMI = kaal / (pikkus/100)^2
   - Näita tulemust
   - Lisa kategooria (alakaal, normaalkaal, ülekaal, rasvumine)

2. **`initDragAndDrop()`**
   - Võimalda drag-and-drop järjestamist
   - Üles/alla nooled (↑/↓) klaviatuuriga liikumiseks
   - PAKETT 12 funktsioon

3. **`toggleInlineNotes(itemId)`**
   - Näita/peida täpsustuste väli
   - Iga quickAdd item'il on oma notes väli

---

### 5. `medportal/js/form-handler.js` (Eksport/Import)

**Roll:** Profiili salvestamine ja laadimine.

**Funktsioonid:**

1. **`exportProfileAsJSON()`**
   - Loe KÕIK vormist (FormData)
   - Konverdi JSON objektiks
   - Lisa meta-info (versioon, kuupäev, profileFilter)
   - Lae alla JSON fail

2. **`importProfileFromJSON(file)`**
   - Loe JSON fail
   - Täida vorm andmetega
   - Taasta profileFilter objekt
   - Taasta quickAdd items

3. **`exportAsText()`**
   - Genereeri TXT fail (inimloetav)
   - 18 sektsiooni
   - Vormindatud

---

### 6. `medportal/config/site-config.js` (Globaalne konfiguratsioon)

**Roll:** Versioon, changelog, lingid.

```javascript
const SITE_CONFIG = {
    version: "1.7.5",
    date: "13.11.2025",
    buildTime: "2025-11-13 01:45",

    changelog: {
        "1.7.5": { ... },
        "1.7.0": { ... },
        ...
    },

    docs: {
        architecture: "../docs/ARCHITECTURE.md",
        development: "../docs/DEVELOPMENT.md",
        fileGuide: "../docs/FILE-GUIDE.md"
    },

    links: [
        { url: "...", description: "..." }
    ],

    promptSections: [
        { id: "profile", label: "Profiiliandmed", default: true },
        { id: "symptoms", label: "Sümptomid", default: true },
        ...
    ]
};
```

---

## TERMINOLOOGIA

### **Profiilifiltri (Profile Filter)**
Süsteem, mis jälgib kasutaja profiili (rasedus, vanus, sugu, meditsiinilised riskid) ja näitab reaalajas hoiatusi.

**Koosneb:**
- Raseduse olek (pregnant, breastfeeding, planning, no)
- Vanusekategooria (18-39, 65-74, 100-120, ...)
- Sugu (male, female, other)
- Meditsiinilised riskid:
  - AF+antikoagulant (kodade virvendus + verevedeldaja)
  - eGFR (neerutalitus)
  - Child-Pugh (maksatalitus)

**Kuidas töötab:**
1. Kasutaja valib profiili (nt "Rasedus 12 nädalat | Noor täiskasvanu | Naine")
2. `updateProfileFilter()` uuendab `profileFilter` objekti
3. `updateProfileWarnings()` näitab hoiatusi (nt "Väldi: ginkgo, ginseng")
4. `updateProfileSummary()` näitab kokkuvõtet sticky header'is

---

### **Plus-nupud (Plus Buttons)**
Kiirvaliku süsteem, mis võimaldab kasutajal valida levinumaid valikuid ühe klikiga.

**Näide:**
```html
<button type="button" class="plus-btn" onclick="quickAddComplaint('peavalu', 'Peavalu')">
    + Peavalu
</button>
```

**Kui kasutaja klikib:**
1. `quickAddComplaint('peavalu', 'Peavalu')` käivitub
2. Luuakse uus `<div class="added-item">` checkbox'i, label'i, info-nupu ja remove-nupuga
3. Lisatakse `quickAddedComplaints` container'isse
4. Näidatakse toast'i "Peavalu lisatud!"

---

### **quickAdd funktsioonid**
Dünaamilise lisamine funktsioonide perekond (nt `quickAddX(key, name)`), mis loob uusi välju vormile.

**Üldine muster:**
```javascript
function quickAddX(key, name) {
    // 1. Loendur
    quickAddCounters.x++;

    // 2. Container
    let container = document.getElementById('quickAddedX');

    // 3. Item div
    const itemDiv = document.createElement('div');
    itemDiv.id = `x_quick_${quickAddCounters.x}`;

    // 4. Checkbox + label + info + remove + notes
    // ...

    // 5. Lisa container'isse
    container.appendChild(itemDiv);

    // 6. Toast
    showToast(`${name} lisatud!`);
}
```

---

### **MED_INFO_DB (Meditsiini Info Andmebaas)**
Andmebaas 112 kirjega, mis sisaldab kaheastmelist infot:
- **Tab A: "Meie andmebaas"** (`ourInfo`) - sisemise meeskonna kirjutatud info
- **Tab B: "Välised allikad"** (`externalInfo`) - linkid NCBI, WHO, Wikipedia'le

**Struktuur:**
```javascript
MED_INFO_DB = {
    'item_key': {
        title: 'Pealkiri',                    // Modaali päis
        shortInfo: 'Lühikirjeldus',           // Hover popup
        ourInfo: `<h4>...</h4><p>...</p>`,    // Tab A
        externalInfo: `<p>...</p>`            // Tab B
    }
}
```

**Kasutamine:**
```javascript
showMedInfo('viirpuu');  // Avab modaali "Viirpuu" infoga
```

---

### **"i"-nupp (Info Icon)**
Info ikoon, mis:
- **Hover:** Näitab `shortInfo` popup'is
- **Klõps:** Avab modaalakna kaheastmelise infoga (Tab A: Meie andmebaas, Tab B: Välised allikad)

**HTML:**
```html
<span class="info-icon" onclick="showMedInfo('viirpuu')">i</span>
```

**JavaScript:**
```javascript
function showMedInfo(key) {
    const info = MED_INFO_DB[key];
    if (!info) return;

    // Ava modaal
    document.getElementById('medModalTitle').textContent = info.title;
    document.getElementById('medModalOurInfo').innerHTML = info.ourInfo;
    document.getElementById('medModalExternalInfo').innerHTML = info.externalInfo;
    document.getElementById('medInfoModal').style.display = 'block';
}
```

---

### **Scope (Välja kategooria)**
Iga välja saab kategoriseerida ühe või mitme scope'i alla:

1. **universal** - Universaalne (kõigile oluline)
   - Privaatsus, punased lipud, kodumõõtmised

2. **demographic** - Demograafiline
   - Rasedus, vanus, sugu

3. **organ** - Elundi-spetsiifiline
   - AF+antikoagulant, eGFR, Child-Pugh

4. **context** - Kontekstuaalne
   - Elupaik, töö, transport

5. **modality** - Modaalsus (ravivõimalus)
   - Taimed, praktikad, vann/saun, muusika

6. **belief** - Usulised/spirituaalsed
   - Paranormaalsed uned, jumalale jagamine, palve, rituaal, bioenergia mõõtjad

**Näide:**
```javascript
// Peavalu on 'universal' (kõigile oluline)
// Rasedus on 'demographic'
// Paranormaalsed uned on 'belief'
```

---

### **Belief-scope (Spirituaalsed väljad)**
Väljad, mis on seotud usuliste/spirituaalsete asjadega.

**Visuaalne eristus:**
- Hall toon taustaga (#f3f4f6)
- '(belief)' märge label'i järel
- Vaikimisi peidetavad meditsiinipersonalile (ekspordi valikutes)

**Belief-scope väljad:**
- Paranormaalsed uned (kehaväline, prohvetlik, šamaani rännak, muu)
- Jumalale jagamine
- Palve
- Rituaal
- New Age praktik
- Alternatiivsed/spirituaalsed mõõtjad (bioenergia, aura, pendel, nõia mõõtmised)

**Ekspordi kontroll:**
```javascript
// Kas kaasata belief-scope väljad AI promptis?
const includeBelief = document.getElementById('includeBelief').checked;
```

---

### **Sticky header (Kleepuv päis)**
Profiilifiltri kokkuvõte, mis jääb ekraani ülaossa kerides.

**HTML:**
```html
<div id="profileSummary" class="sticky-header">
    Rasedus 12 nädalat | Noor täiskasvanu (18-39 a) | Naine
</div>
```

**CSS:**
```css
.sticky-header {
    position: sticky;
    top: 0;
    background: #f0f9ff;
    padding: 10px;
    z-index: 100;
}
```

---

### **Toast (Popup-teade)**
Kasutaja tagasiside süsteem (popup-teade ekraani all).

**Näide:**
```javascript
showToast("Peavalu lisatud!");
```

**HTML (dünaamiliselt loodud):**
```html
<div class="toast">Peavalu lisatud!</div>
```

**CSS:**
```css
.toast {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: #10b981;
    color: white;
    padding: 15px 20px;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    animation: slideIn 0.3s, slideOut 0.3s 2.7s;
}
```

---

### **Drag-and-drop (Lohistamine)**
Süsteem, mis võimaldab järjestada valikuid lohistades.

**HTML:**
```html
<div class="added-item" draggable="true" ondragstart="drag(event)">
    <button onclick="moveUp(this)">↑</button>
    <button onclick="moveDown(this)">↓</button>
    Peavalu
</div>
```

**JavaScript:**
```javascript
function drag(event) {
    event.dataTransfer.setData("text", event.target.id);
}

function drop(event) {
    event.preventDefault();
    const data = event.dataTransfer.getData("text");
    event.target.appendChild(document.getElementById(data));
}

function moveUp(button) {
    const item = button.parentElement;
    const prev = item.previousElementSibling;
    if (prev) item.parentElement.insertBefore(item, prev);
}

function moveDown(button) {
    const item = button.parentElement;
    const next = item.nextElementSibling;
    if (next) item.parentElement.insertBefore(next, item);
}
```

---

### **Presett (Eelseadistatud konfiguratsioon)**
Eelseadistatud konfiguratsioon (nt Privaatsuse filtri: Minimaalne/Tavaline/Täielik).

**Näide (PAKETT 13):**
```javascript
function applyPrivacyPreset(level) {
    // Minimaalne: ainult põhiline info
    if (level === 'minimal') {
        uncheckAll(['usk', 'maailmavaade', 'seksuaalsus', 'finants', 'töö', 'perekond',
                    'vaimne_tervis', 'sõltuvused', 'trauma', 'õiguslik', 'geneetiline',
                    'alternatiivmeditsiin', 'sotsiaal', 'muu']);
    }

    // Tavaline: enamik, v.a intiimsed
    if (level === 'normal') {
        checkAll(['kodu_olukord', 'sotsiaal', 'finants', 'töö']);
        uncheckAll(['seksuaalsus', 'trauma', 'õiguslik', 'vaimne_tervis', 'sõltuvused']);
    }

    // Täielik: kõik
    if (level === 'full') {
        checkAll(['usk', 'maailmavaade', 'seksuaalsus', 'finants', 'töö', 'perekond',
                  'vaimne_tervis', 'sõltuvused', 'trauma', 'õiguslik', 'geneetiline',
                  'alternatiivmeditsiin', 'sotsiaal', 'muu']);
    }
}
```

---

## KUIDAS SÜSTEEMID OMAVAHEL SUHTLEVAD?

### 1. **Kasutaja valib plus-nupu** → **quickAdd funktsioon** → **MED_INFO_DB** → **Toast**

```
[Kasutaja klikib "+ Peavalu"]
        ↓
quickAddComplaint('peavalu', 'Peavalu')
        ↓
    Loo <div class="added-item">
        ↓
    Lisa info-nupp (kui MED_INFO_DB['peavalu'] on olemas)
        ↓
    Lisa container'isse
        ↓
    Näita toast'i "Peavalu lisatud!"
```

---

### 2. **Kasutaja muudab profiili** → **updateProfileFilter()** → **updateProfileWarnings()**

```
[Kasutaja valib "Rasedus"]
        ↓
updateProfileFilter()
        ↓
    profileFilter.pregnancy = 'pregnant'
        ↓
updateProfileWarnings()
        ↓
    Kontrolli: kas rasedus?
        ↓
    JAH → Näita hoiatust "Väldi: ginkgo, ginseng, naistepuna, lagrits, kelp"
```

---

### 3. **Kasutaja klikib "i"-nupul** → **showMedInfo()** → **MED_INFO_DB** → **Modaal**

```
[Kasutaja klikib info-nupul "Viirpuu"]
        ↓
showMedInfo('viirpuu')
        ↓
    Leia MED_INFO_DB['viirpuu']
        ↓
    Täida modaali:
        - Päis: info.title
        - Tab A: info.ourInfo
        - Tab B: info.externalInfo
        ↓
    Ava modaal (display: block)
```

---

### 4. **Kasutaja ekspordib profiili** → **exportProfileAsJSON()** → **JSON fail**

```
[Kasutaja klikib "Ekspordi JSON"]
        ↓
exportProfileAsJSON()
        ↓
    Loe KÕIK vormist (FormData)
        ↓
    Lisa meta-info:
        - version: "1.7.5"
        - date: "2025-11-13"
        - profileFilter: { ... }
        ↓
    Konverdi JSON objektiks
        ↓
    Lae alla fail "medical-profile-2025-11-13.json"
```

---

## TULEVIKUPLAAN: MED_INFO_DB ARHITEKTUUR (v2.0)

### PRAEGUNE PROBLEEM:
- 112 kirjet on `info-system.js` failis (2859 rida)
- Käsitsi muutmine on raske
- Mitmekeelne tugi puudub
- Massiivne uuendamine AI-ga on keeruline

### LAHENDUS (v2.0 jaoks):

#### 1. **Eralda JSON failidesse**
```
medportal/data/med-info/
├── herbs.json          (taimed: viirpuu, arjuna, hibiskus, ...)
├── events.json         (sündmused: haiglaravi, EMO, ...)
├── allergies.json      (allergiad: penitsilliin, aspirin, ...)
├── diagnostics.json    (diagnostika: röntgen, CT, ...)
├── complaints.json     (kaebused: peavalu, liigesevalu, ...)
├── sleep.json          (uni: norskamine, painajad, ...)
├── privacy.json        (privaatsus: jagamise tase, nõusolek, ...)
└── ...
```

#### 2. **Mitmekeelne süsteem**
```json
{
    "viirpuu": {
        "title": {
            "et": "Viirpuu (Crataegus)",
            "en": "Hawthorn (Crataegus)",
            "ru": "Боярышник (Crataegus)",
            "pl": "Głóg (Crataegus)",
            "he": "עוזרר (Crataegus)",
            "zh": "山楂 (Crataegus)"
        },
        "shortInfo": {
            "et": "Südamele toetav taim...",
            "en": "Heart-supportive herb...",
            "ru": "Растение для поддержки сердца...",
            "pl": "Roślina wspierająca serce...",
            "he": "צמח תומך בלב...",
            "zh": "支持心脏的草药..."
        },
        "ourInfo": {
            "et": "<h4>Viirpuu</h4><p>...</p>",
            "en": "<h4>Hawthorn</h4><p>...</p>",
            ...
        },
        "externalInfo": {
            "et": "<p>Lisalugemist...</p>",
            "en": "<p>Further reading...</p>",
            ...
        }
    }
}
```

#### 3. **JavaScript laadija**
```javascript
// Lae kõik JSON failid
async function loadMedInfoDB() {
    const categories = ['herbs', 'events', 'allergies', 'diagnostics', 'complaints', 'sleep', 'privacy'];
    const lang = localStorage.getItem('lang') || 'et';

    MED_INFO_DB = {};

    for (const cat of categories) {
        const response = await fetch(`/data/med-info/${cat}.json`);
        const data = await response.json();

        // Tõlgi õigesse keelde
        for (const [key, item] of Object.entries(data)) {
            MED_INFO_DB[key] = {
                title: item.title[lang] || item.title.et,
                shortInfo: item.shortInfo[lang] || item.shortInfo.et,
                ourInfo: item.ourInfo[lang] || item.ourInfo.et,
                externalInfo: item.externalInfo[lang] || item.externalInfo.et
            };
        }
    }
}

// Lae lehekülg laadides
document.addEventListener('DOMContentLoaded', loadMedInfoDB);
```

#### 4. **Admin/CRM portaal** (v2.1 jaoks)
```
medportal/admin/
├── index.html              (admin sisselogimine)
├── edit-info.html          (MED_INFO_DB muutmine)
├── js/
│   ├── admin.js            (CRUD operatsioonid)
│   └── translator.js       (AI-ga automaatne tõlkimine)
└── css/
    └── admin.css
```

**Funktsioonid:**
- Lisa uus info kirje
- Muuda olemasolevat
- Kustuta (arhiveeri)
- Massiline import CSV/JSON
- AI-ga automaatne tõlkimine (6 keelt)
- Versioonihaldus (audit log)

**Näide UI:**
```
┌─────────────────────────────────────┐
│ MED_INFO_DB Admin                   │
├─────────────────────────────────────┤
│ [+ Lisa uus kirje]                  │
│                                     │
│ Otsi: [____________] [Otsi]         │
│                                     │
│ ┌─────────────────────────────────┐ │
│ │ viirpuu                         │ │
│ │ Kategooria: herbs               │ │
│ │ Keeled: ✓ ET ✓ EN ✗ RU ✗ PL    │ │
│ │ [Muuda] [Kustuta] [Tõlgi AI-ga] │ │
│ └─────────────────────────────────┘ │
│ ┌─────────────────────────────────┐ │
│ │ arjuna                          │ │
│ │ Kategooria: herbs               │ │
│ │ Keeled: ✓ ET ✓ EN ✓ RU ✗ PL    │ │
│ │ [Muuda] [Kustuta] [Tõlgi AI-ga] │ │
│ └─────────────────────────────────┘ │
└─────────────────────────────────────┘
```

#### 5. **AI-ga massiline uuendamine**
```javascript
// API endpoint
POST /api/translate-info
{
    "key": "viirpuu",
    "from": "et",
    "to": ["en", "ru", "pl", "he", "zh"]
}

// AI vastus
{
    "success": true,
    "translations": {
        "en": { ... },
        "ru": { ... },
        "pl": { ... },
        "he": { ... },
        "zh": { ... }
    }
}

// Inimese heakskiit
// → Salvesta JSON faili
// → Uuenda version history
```

---

## KOKKUVÕTE

Medical Portal v1.7.5 on **massiivne holistilik medisiiniportaal** koos:

✅ **6692 rida JavaScripti** (10 faili)
✅ **112 info kirjet** MED_INFO_DB's
✅ **50+ plus-nuppu** kiirvaliku jaoks
✅ **Profiilifiltri süsteem** (rasedus, vanus, sugu, riskid)
✅ **Belief-scope süsteem** (spirituaalsed väljad)
✅ **13 PAKETTI** (v1.7.0 → v1.7.5)

**Järgmine samm:** v1.7.6
- Plus-süsteemi käitumine (uued ESIMESENA)
- UI puhastus (lühemad väljad)
- Puuduvad plus-süsteemid (allergiad, ravimid, taimravi, diagnostika)
- Automaatne kokkuvõte (JSON genereerimine)

**Tulevikuplaan:** v2.0
- MED_INFO_DB JSON failidesse
- Mitmekeelne tugi (6 keelt)
- Admin/CRM portaal
- AI-ga massiline uuendamine

---

**Loodud:** 13.11.2025 02:05
**Autor:** Claude AI
**Versioon:** v1.7.5
**Eelmine uuendus:** v1.7.5 (13 PAKETTI)

Meigo Medical Medisiiniportaal | CODE ARCHITECTURE v1.7.5
